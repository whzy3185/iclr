# F0 Source-Only Feasibility Result

> Snapshot status: `INTERRUPTED_FOR_USER_REQUESTED_PUSH`.
>
> This file is included for provenance of the current pushed work, but it is not the final F0 feasibility decision. A first automated run completed with zero matched coverage because the initial seed leakage gate was too conservative and blocked all extractable seeds before retrieval/matching. The pipeline script has since been corrected to route extractable but human-review-needed seeds into source-only retrieval/matching while preserving leakage flags. The corrected run was interrupted before completion at the user's request to push current work.

## Recommendation

`PENDING_CORRECTED_RERUN`

This is a constructibility recommendation only. F0 did not run no-context generations, evidence-conditioned generations, proposal evaluation, baseline propensity estimation, or treatment-effect inspection.

The numeric counts below are retained from the first completed automated run and should be read as a failed-pipeline diagnostic, not as final source feasibility evidence.

## Key Counts

- ICLR 2025 evidence papers audited: 3703 total, 3669 parsed with title+abstract.
- ICLR 2026 candidate seeds audited: 5351.
- Extractable method-masked seeds: 2809.
- Seed validity/leakage provisional pass candidates: 0.
- Unique seeds with >=2 source-supported routes: 0.
- Unique seeds with >=3 source-supported routes: 0.
- Unique seeds with at least one route pair supporting >=6 / >=8 / >=12 strict pairwise matched evidence slots: 0 / 0 / 0.
- Route-clear k8 source-feasible blocks awaiting human equipoise: 0.
- Potential final experimental blocks after F0: 0 certified; all require F1 human seed/equipoise/source-route audit.

## R1-R4 Coverage



## Subfield Coverage

- : audited=2534, k8_matchable_unique_seeds=0
- data_evaluation: audited=274, k8_matchable_unique_seeds=0
- general_ml: audited=16, k8_matchable_unique_seeds=0
- generative_models: audited=115, k8_matchable_unique_seeds=0
- graphs: audited=89, k8_matchable_unique_seeds=0
- language_models: audited=1009, k8_matchable_unique_seeds=0
- optimization_theory: audited=240, k8_matchable_unique_seeds=0
- reinforcement_learning: audited=313, k8_matchable_unique_seeds=0
- robustness_safety: audited=190, k8_matchable_unique_seeds=0
- vision_multimodal: audited=571, k8_matchable_unique_seeds=0

## Pairwise Matching vs Loose Packet-Level Coverage

Loose packet-level k8 unique seeds: 0. Route-clear pairwise k8 unique seeds: 0. Pairwise matching therefore does not materially reduce coverage under the frozen heuristic calipers.

Raw route-pair support before route-clear filtering appears in `route_pair_coverage.csv`; route-clear pairwise results appear in `route_pair_matchability.csv` and `matched_evidence_slots.csv`.

## Route Purity

Route-clear source papers: 1773. Mixed/ambiguous source papers: 1896. Route-clear filtering leaves enough automated matched slots for a narrow source-only bank, but these labels are keyword-provisional and require `route_annotation_audit_packet.csv` human review before any treatment use.

## Artifact/Knowledge Axis

The coarse Artifact/Knowledge/Both/Unclear axis is easier to audit mechanically than the fine route taxonomy because BUILD maps mostly to artifact contribution while DIAGNOSE/MEASURE/EXPLAIN map mostly to knowledge contribution. It is not a replacement for the predeclared R1-R4 route taxonomy, and it is recorded only as an external robustness axis.

## Main Bottleneck

Dominant blocker: `temporal_uncertainty`.

The strongest unresolved causal-core issue is temporal cleanliness: proceedings pages provide accepted-paper abstracts and publication-date metadata, but do not certify earliest public date or absence of pre-2024-08-31 versions. Seed leakage and method neutrality also need human review because seeds were automatically masked from focal abstracts. Mixed-route contamination remains a secondary blocker because many abstracts contain build+evaluate or diagnose+mitigate contributions.

## Best-Fit Areas

Best automated coverage is in the subfields with the largest k8 counts above. Route pairs with the largest k8 seed coverage are the most promising R1-R4 contrasts. R4 should be treated carefully because Round 27 identifies DIAGNOSE vs EXPLAIN as often complementary/high-composability.

## Attrition Waterfall

1. ICLR 2026 focal candidates: 5351
2. Extractable method-masked seeds: 2809
3. Seed validity/leakage pass candidates: 0
4. Multi-route-open candidates: 0
5. >=2 source-supported routes: 0
6. Relevance-matchable route pairs: k6=0, k8=0, k12=0 unique seeds
7. Source-feasible blocks awaiting human equipoise: 0
8. Potential final experimental blocks: 0 certified in F0; F1 required

## Human Review Required Before F1/P0

- `seed_validity_audit_packet.csv`
- `route_equipoise_audit_packet.csv`
- `route_annotation_audit_packet.csv`
- `temporal_cleanliness_report.md`
- `matching_diagnostics/unmatched_papers.csv`
- `matching_diagnostics/retrieval_candidates.csv`

## Stop Statement

F0 source-only artifacts are complete. This task stops here and does not enter P0.
