# Temporal Cleanliness Report

Source used: ICLR official proceedings pages for 2025 evidence and 2026 focal candidates.

OpenReview bulk API status: `bulk_api_challenge_required_403_on_2026-09-07; proceedings used as primary source`.

Evidence papers parsed: 3669 / 3703.

Proceedings publication date field is available in parsed pages, but it is not an earliest-public-version guarantee. Therefore first-public date is recorded as the proceedings publication date source field, while `temporal_status` remains `PROCEEDINGS_PUBLICATION_AFTER_2024_08_31_BUT_FIRST_PUBLIC_UNKNOWN` for successfully parsed ICLR 2025 evidence papers.

Strict shared evidence subset status: not certified by F0 automation. No earlier arXiv/OpenReview version search was completed at scale, so temporal cleanliness is the dominant unresolved gate for a causal-core run using Gemma 3's August 2024 cutoff.
